<?php
    include("layout/header.php")
?>
<body>
    <div class="container-fluid">
        <h3 class="mb-4 text-center"><img src="assets/images/sipmakbodybg.jpg" style="width: 100%;;height: 100%;" alt=""></h3>
<?php
    include("layout/footer.php")
?>