<?php
include "config.php";
    $id_pelanggan = $_POST['id'];
    $nobuku   = $_POST['nobuku_plat'];
    $nama_pemohon = $_POST['nama_pemohon'];    
    $nohp_pemohon    = $_POST['nohp_pemohon'];
    $nama_jenazah     = $_POST['nama_jenazah'];
    $usia_jenazah    = $_POST['usia_jenazah'];
    $lokasi_makam    = $_POST['lokasi_makam'];
    $ijin_berlaku    = $_POST['ijin_berlaku'];
    $biaya    = $_POST['biaya'];
    $status_bayar    = $_POST['status_bayar'];
    $metode_pembayaran    = $_POST['metode_pembayaran'];


$query  = "INSERT INTO pembayaran(id_pelanggan, nobuku_plat, nama_pemohon, nohp_pemohon, nama_jenazah, usia_jenazah, lokasi_makam, ijin_berlaku, biaya, status_bayar, metode_pembayaran) 
VALUES ('$id_pelanggan','$nobuku','$nama_pemohon','$nohp_pemohon','$nama_jenazah','$usia_jenazah','$lokasi_makam','$ijin_berlaku','$biaya','AKAN MEMBAYAR','$metode_pembayaran')";
$result = mysqli_query($koneksi, $query);
    if(!$result){
        die ("Query gagal dijalankan: ".mysqli_errno($koneksi).
                             " - ".mysqli_error($koneksi));
    } else {
        //tampil alert dan akan redirect ke halaman index.php
        //silahkan ganti index.php sesuai halaman yang akan dituju
        echo "<script>alert('Data berhasil disimpan. Jika pilihan Anda membayar tunai, harus diselesaikan per hari ini');window.location='../print.php?id="$nobuku"';</script>";
    }