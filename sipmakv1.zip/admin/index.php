<?php
    include("template/sidehead.php");
?>
<body>
<div class="container-fluid">

</div>
<?php
    include("template/footer.php");
?>